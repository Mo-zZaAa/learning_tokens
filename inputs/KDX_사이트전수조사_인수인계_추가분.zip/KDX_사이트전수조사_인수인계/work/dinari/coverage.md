# 수집과 반영 점검

| 호스트 | 구역 | 전체 | 정독(read) | 훑기(skim) | 목록만(list) | 제외(skip) | 수집완료 |
|---|---|---|---|---|---|---|---|
| api-enterprise.sandbox.dinari.com | api | 1 | 1 | 0 | 0 | 0 | 0 |
| api-enterprise.sbt.dinari.com | api | 2 | 2 | 0 | 0 | 0 | 0 |
| app.dinari.com | (home) | 1 | 1 | 0 | 0 | 0 | 1 |
| app.dinari.com | transparency | 1 | 1 | 0 | 0 | 0 | 1 |
| app.dinari.com | portfolio | 1 | 1 | 0 | 0 | 0 | 1 |
| app.dinari.com | trade | 1 | 1 | 0 | 0 | 0 | 1 |
| app.dinari.com | orders | 1 | 1 | 0 | 0 | 0 | 1 |
| app.dinari.com | spcx | 1 | 1 | 0 | 0 | 0 | 1 |
| assets.dinari.com | audits | 4 | 4 | 0 | 0 | 0 | 4 |
| assets.dinari.com | forms | 1 | 1 | 0 | 0 | 0 | 1 |
| assets.dinari.com | security | 1 | 1 | 0 | 0 | 0 | 0 |
| dinari.com | blog | 74 | 74 | 0 | 0 | 0 | 74 |
| dinari.com | dshares | 11 | 11 | 0 | 0 | 0 | 11 |
| dinari.com | case-studies | 10 | 10 | 0 | 0 | 0 | 10 |
| dinari.com | bd | 10 | 10 | 0 | 0 | 0 | 7 |
| dinari.com | business | 3 | 3 | 0 | 0 | 0 | 1 |
| dinari.com | us | 2 | 2 | 0 | 0 | 0 | 2 |
| dinari.com | (home) | 1 | 1 | 0 | 0 | 0 | 1 |
| dinari.com | privacy | 1 | 1 | 0 | 0 | 0 | 1 |
| dinari.com | terms | 1 | 1 | 0 | 0 | 0 | 1 |
| dinari.com | terms-conditions-usdplus-stusdplus-tokens | 1 | 1 | 0 | 0 | 0 | 1 |
| dinari.com | careers | 1 | 1 | 0 | 0 | 0 | 1 |
| dinari.com | contact-us | 1 | 1 | 0 | 0 | 0 | 1 |
| dinari.com | usdplus | 1 | 1 | 0 | 0 | 0 | 1 |
| dinari.com | money2020 | 1 | 1 | 0 | 0 | 0 | 1 |
| dinari.com | spdm | 1 | 1 | 0 | 0 | 0 | 1 |
| dinari.com | work-with-dinari | 1 | 1 | 0 | 0 | 0 | 1 |
| dinari.com | partners | 1 | 1 | 0 | 0 | 0 | 1 |
| dinari.com | direct-indexing-portfolios | 1 | 1 | 0 | 0 | 0 | 1 |
| dinari.com | cdn-cgi | 1 | 1 | 0 | 0 | 0 | 0 |
| dinari.com | get-started | 1 | 1 | 0 | 0 | 0 | 1 |
| dinari.com | referrals | 1 | 1 | 0 | 0 | 0 | 0 |
| dinari.com | launch | 1 | 1 | 0 | 0 | 0 | 1 |
| dinari.com | disclosures | 1 | 1 | 0 | 0 | 0 | 0 |
| docs.dinari.com | login | 124 | 0 | 0 | 0 | 124 | 0 |
| docs.dinari.com | reference | 73 | 66 | 7 | 0 | 0 | 73 |
| docs.dinari.com | docs | 53 | 46 | 7 | 0 | 0 | 50 |
| docs.dinari.com | changelog | 18 | 18 | 0 | 0 | 0 | 15 |
| docs.dinari.com | user-guide | 3 | 3 | 0 | 0 | 0 | 0 |
| docs.dinari.com | v | 2 | 2 | 0 | 0 | 0 | 0 |
| docs.dinari.com | v2.0 | 2 | 2 | 0 | 0 | 0 | 2 |
| docs.dinari.com | reference-link | 2 | 2 | 0 | 0 | 0 | 2 |
| docs.dinari.com | (home) | 1 | 1 | 0 | 0 | 0 | 1 |
| docs.dinari.com | api | 1 | 1 | 0 | 0 | 0 | 0 |
| docs.dinari.com | architecture | 1 | 1 | 0 | 0 | 0 | 0 |
| docs.dinari.com | ](https: | 1 | 1 | 0 | 0 | 0 | 0 |
| docs.dinari.com | cdn-cgi | 1 | 0 | 0 | 0 | 1 | 0 |
| partners.dinari.com | (home) | 1 | 1 | 0 | 0 | 0 | 1 |
| partners.dinari.com | auth | 1 | 1 | 0 | 0 | 0 | 0 |
| sbt.dinari.com | tokens | 23 | 23 | 0 | 0 | 0 | 23 |
| sbt.dinari.com | (home) | 1 | 1 | 0 | 0 | 0 | 1 |
| sbt.dinari.com | defi | 1 | 1 | 0 | 0 | 0 | 1 |
| status.dinari.com | (home) | 1 | 1 | 0 | 0 | 0 | 1 |
| usd.dinari.com | (home) | 1 | 1 | 0 | 0 | 0 | 1 |
| usd.dinari.com | transparency | 1 | 1 | 0 | 0 | 0 | 1 |
| usd.dinari.com | wrap | 1 | 1 | 0 | 0 | 0 | 1 |
| www.dinari.com | blog | 2 | 2 | 0 | 0 | 0 | 0 |
| www.dinari.com | post | 2 | 2 | 0 | 0 | 0 | 2 |
| www.dinari.com | terms | 1 | 1 | 0 | 0 | 0 | 1 |
| www.dinari.com | (home) | 1 | 1 | 0 | 0 | 0 | 1 |
| www.dinari.com | transparency | 1 | 1 | 0 | 0 | 0 | 1 |
| www.dinari.com | referrals | 1 | 1 | 0 | 0 | 0 | 0 |
| www.dinari.com | ](https: | 1 | 1 | 0 | 0 | 0 | 0 |
| 합계 |  | 464 | 325 | 14 | 0 | 125 | 308 |

## 수집 대기: 0건
## 차단: 0건
## 오류: 0건
## 내용 거의 없음: 3건
- https://docs.dinari.com/changelog/v20251223-d86787c 
- https://docs.dinari.com/changelog/v20251229-502a74e 
- https://docs.dinari.com/changelog/v20260113-22d5943 