---
url: https://app.ondo.finance/intelligent-portfolios/blkhion
title: BLKHIon: Ondo High Income Powered by BlackRock | Ondo
description: The Ondo High Income Powered by BlackRock portfolio delivers diversified fixed income exposure. The token offers exposure to a modeled portfolio of iShares fixed income ETFs spanning flexible and total-return income, securitized debt, investment-grade credit, short duration, and high yield.
fetched: 2026-11-16
method: render
plan: read
---

[그림: ousg logo]

US Users: OUSG is available in your region

Built for institutional investors, OUSG offers exposure to short-term US Treasuries with 24/7 instant mints and redemptions. View Details

###### Access Restricted

# Ondo Stocks

The content you are trying to access is not accessible in your jurisdiction.

Ondo Stocks are not registered under the Securities Act of 1933, as amended (the "Act"). Ondo Stocks are not offered or sold in the US, to US persons (as defined in Rule 902(k) of the Act), or for the account or benefit of US persons, or in or to persons in other restricted jurisdictions.

[View Eligibility Restrictions](https://docs.ondo.finance/ondo-stocks/eligibility)[Back to Home](https://ondo.finance/)

## 펼치거나 눌러야 보이던 내용

### US Users: OUSG is available in your region 누른 뒤

- Sign Up / Log In
- About
- Statistics
- Pay
- 0
- Receive
- 0
- Privacy Policy
- [*] OUSG tokens have not been registered under the US Securities Act of 1933, as amended (the "Act") or the securities or financial instrument laws of any other jurisdiction, and are available solely to persons who are accredited investors (as defined in Rule 501 of Regulation D under the Act) and qualified purchasers (as defined in Section 2(a)(51) of the US Investment Company Act of 1940, as amended (the "40 Act")). The issuer of OUSG is Ondo I LP, a Delaware (USA) limited partnership (the "Fund") is not registered as an investment company under the 40 Act or as an Alternative Investment Fund or Undertaking for Collective Investment in Transferable Securities in the European Economic Area, or under the securities or financial instrument laws of any other jurisdiction.
- Ondo Finance Inc., a Delaware (USA) corporation, provides tokenization services to, and is also the sole member of both the general partner of the Fund and the investment adviser to the Fund, Ondo Capital Management LLC (the "Adviser"). The Adviser is a Registered Investment Adviser registered with the U.S. Securities and Exchange Commission ("SEC"). The Adviser's current written disclosure statement (Form ADV Part 2A) discussing its advisory services and fees is available upon request or at the SEC's Investment Adviser Public Disclosure website (www.adviserinfo.sec.gov). Registration as an investment adviser does not imply a certain level of skill or training. The Adviser shall not be responsible for any errors or omissions, or for the results obtained from the use of the information provided by the Adviser, the Fund or any of their respective affiliates, control persons, agents or representatives.
- The OUSG issuer, its affiliates, their respective shareholders and members, and their respective directors, officers, employees, consultants, agents and representatives (the "Ondo Persons") do not endorse, the Ondo Persons do not make any representation or warranty whatsoever (express or implied, including but not limited to any warranty of merchantability, fitness for a particular purpose, or non-infringement) regarding, and THE ONDO PERSONS SHALL NOT HAVE ANY LIABILITY WHATSOEVER WITH RESPECT TO ANYONE'S USE OF, any third-party products, services or technologies referenced herein.
- The communications herein are only intended for eligible purchasers of, or for actual or potential business relationships or technical integrations with respect to, OUSG. Nothing herein constitutes any offer to sell, or any solicitation of an offer to buy, any assets. Nothing herein constitutes investment, legal, tax or financial advice. Acquiring tokens involves risks. A holder of tokens may incur losses, including total loss of their purchase price. Past performance may not be (and for the tokens will not be) an indication of future results. Investors are responsible for conducting their own research, investigation, verification, checks or consultation for professional or investment advice.
- This communication may contain forward-looking statements, including, but not limited to, statements regarding future financial performance, business strategies, or expectations for Ondo Finance's growth and development. These statements are based on management's current expectations, estimates, projections, and beliefs, and are subject to a number of risks, uncertainties, and assumptions that could cause actual results to differ materially from those anticipated. Forward-looking statements can be identified by the use of terminology such as "may," "will," "should," "expect," "intend," "plan," "anticipate," "believe," "estimate," "predict," "potential," "continue," or the negative of these terms or other similar expressions. Factors that could cause actual results to differ materially from those contemplated by the forward-looking statements include, but are not limited to, the following: economic, competitive, legal, governmental, and technological factors affecting Ondo Finance's operations, markets, products, services, and prices. Neither Ondo Finance nor any of their respective affiliates undertakes any obligation to update or revise any forward-looking statements, whether as a result of new information, future events, or otherwise, except as required by law.
- Additional terms and restrictions apply. See docs.ondo.finance/legal/terms-of-service, https://docs.ondo.finance/qualified-access-products/ousg, https://ondo.finance/ousg, app.ondo.finance and (as applicable) the Token offering documents for details.
- ¹ APY is generally updated each weekday, excluding holidays. APY is calculated based on the average income, net of expenses, earned over the 30 calendar days preceding and including the day that APY is updated. This yield reflects past performance. Past performance is not indicative of future results. Actual yields may vary depending on market conditions and other factors. ² Yields are generally updated each weekday, excluding holidays. 7-Day Yield is calculated based on the average income, net of expenses, earned over the 7 calendar days preceding and including the day that the 7-Day Yield is updated. 30-Day Yield is calculated based on the average income, net of expenses, earned over the 30 calendar days preceding and including the day that the 30-Day Yield is updated. These yields reflect past performance. Past performance is not indicative of future results. Actual yields may vary depending on market conditions and other factors. ³ Current Value excludes OUSG limited partnership interests represented in book-entry (non-tokenized) form. ⁴ Other Assets consists funds in transit, outstanding receivables less payables

## 구조화 데이터(JSON-LD)

```json
{"@context":"https://schema.org","@graph":[{"@type":"WebApplication","@id":"https://app.ondo.finance/#webapp","name":"Ondo","url":"https://app.ondo.finance","applicationCategory":"FinanceApplication","operatingSystem":"Web browser","description":"Ondo is the platform for qualified users to buy and sell tokenized stocks, ETFs, and Treasuries onchain.","publisher":{"@id":"https://ondo.finance/#organization"}}]}
{"@context":"https://schema.org","@type":"FinancialProduct","name":"Ondo High Income Powered by BlackRock (BLKHIon)","description":"The Ondo High Income Powered by BlackRock portfolio delivers diversified fixed income exposure. The token offers exposure to a modeled portfolio of iShares fixed income ETFs spanning flexible and total-return income, securitized debt, investment-grade credit, short duration, and high yield.","url":"https://app.ondo.finance/intelligent-portfolios/blkhion","provider":{"@type":"Organization","name":"Ondo Finance","url":"https://ondo.finance"}}
```