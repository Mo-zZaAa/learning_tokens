---
url: https://blog.kraken.com/news/payward-acquires-bitnomial
title: Payward to acquire Bitnomial, creating a fully CFTC-licensed derivatives platform - Kraken Blog Kraken Blog
description: 
fetched: 2026-11-16
method: static
plan: skim
---

April 17, 2026
 | 
[News](https://blog.kraken.com/category/news)

# Payward to acquire Bitnomial, creating a fully CFTC-licensed derivatives platform

Combination of Bitnomial’s decade-built US regulatory infrastructure and Payward’s global distribution, scale, and multi-brand operating model to create one of the most comprehensively regulated and vertically integrated U.S. derivatives platforms

### Share this:

* [Share on X (Opens in new window)
  X](https://blog.kraken.com/news/payward-acquires-bitnomial?share=twitter)
* [Share on LinkedIn (Opens in new window)
  LinkedIn](https://blog.kraken.com/news/payward-acquires-bitnomial?share=linkedin)
* [Share on Facebook (Opens in new window)
  Facebook](https://blog.kraken.com/news/payward-acquires-bitnomial?share=facebook)

We’re excited to announce we have entered into a definitive agreement to acquire Bitnomial, the first fully CFTC-licensed derivatives company in the United States built for digital assets, for up to $550 million payable in cash and stock, in a transaction that values Payward’s equity at $20 billion.

Bitnomial is the first crypto-native exchange in the United States to hold all three CFTC-issued licenses required to operate a full-stack domestic crypto trading and derivatives business. The combination brings together Bitnomial’s fully CFTC-licensed infrastructure with our global client base, deep liquidity, and distribution across Kraken, NinjaTrader, and its broader product family.

This acquisition gives us access to a regulated foundation that takes years to build. Bitnomial spent over a decade securing the full set of US derivatives licenses — exchange, clearinghouse, and brokerage — becoming the first company in the United States to have assembled this stack with digital assets in mind.

**Arjun Sethi, Co-CEO of Payward and Kraken**: “The shape of a market is determined by its clearing infrastructure, not its front end. Settlement mechanics, margin models, and contract structures define what products can exist and who can access them. The US has had no clearing infrastructure built for digital assets.”

“Bitnomial spent a decade building it: crypto settlement, crypto collateral, continuous 24/7 markets. These are capabilities that cannot be retrofitted onto legacy systems. They have to be built natively. That is the regulated foundation we are adding to Payward, starting with spot margin, perpetuals, and options for US clients under CFTC regulation.”

**Luke Hoersten, Founder and CEO of Bitnomial:** “Bitnomial was built on a simple conviction: that the future of derivatives is digital-asset-native, and that the US should lead it, not follow it. That’s why we built our exchange and clearinghouse from the ground up for crypto — and it’s why Bitnomial has been first on nearly every meaningful capability: the first-ever US perpetual futures, the first CFTC-regulated crypto margin collateral, native crypto settlement, and a unified book across spot, futures, options, and perpetuals.”

“These are things adapted legacy infrastructure simply can’t retrofit. That same foundation is what makes the next generation of derivatives possible: crypto-settled products, tokenized assets, and eventually the kind of continuous, capital-efficient contracts that have transformed global markets. Joining Payward means we can now build that future at the scale it deserves.”

Through Payward Services, our B2B infrastructure platform, the acquisition also opens a new channel for partners, including fintechs, banks, brokerages, and payment providers, to offer regulated US derivatives products to their own end users through a single integration.

Payward Services gives partners access to a broad range of financial infrastructure capabilities through a single set of APIs, including crypto trading, tokenized equities, staking, on/off-ramps, and now regulated US derivatives.

With the acquisition of Bitnomial, we now offer a regulated derivatives offering across all of our major markets. The acquisition builds on our multi-year track record of establishing regulated derivatives presence globally. We acquired the first licensed crypto futures platform in the UK in 2019 and launched a regulated EU derivatives offering in 2025.

We continue to lead policy engagement to establish regulatory clarity and drive innovation around the world for all of our products and services. Passage of comprehensive market structure legislation in the US remains one of our top policy priorities.

We plan to scale Bitnomial’s team and operations as we build out our US derivatives capabilities, drawing on the expertise Bitnomial has developed over more than a decade of building and operating regulated crypto markets infrastructure.

### **Transaction details**

Under the terms of the agreement, which values Payward’s equity at $20 billion, Payward will acquire 100% of the outstanding equity of Bitnomial for up to $550 million payable in cash and stock.

The transaction is subject to customary closing conditions and is expected to close in the first half of 2026. Required CFTC notices will be filed in connection with the closing.

### **Advisors**

PJT Partners served as exclusive financial advisor, Haynes Boone served as legal advisor, and Katten Muchin Rosenman LLP served as regulatory advisor to Bitnomial. Jones Day served as legal advisor, and Morrison Foerster LLP served as regulatory advisor to Payward.

### Share this:

* [Share on X (Opens in new window)
  X](https://blog.kraken.com/news/payward-acquires-bitnomial?share=twitter)
* [Share on LinkedIn (Opens in new window)
  LinkedIn](https://blog.kraken.com/news/payward-acquires-bitnomial?share=linkedin)
* [Share on Facebook (Opens in new window)
  Facebook](https://blog.kraken.com/news/payward-acquires-bitnomial?share=facebook)

## 구조화 데이터(JSON-LD)

```json
{"@context":"https:\/\/schema.org","@graph":[{"@type":"Article","@id":"https:\/\/blog.kraken.com\/news\/payward-acquires-bitnomial#article","isPartOf":{"@id":"https:\/\/blog.kraken.com\/news\/payward-acquires-bitnomial"},"author":{"name":"KrakenFX","@id":"https:\/\/blog.kraken.com\/#\/schema\/person\/87e55a5e8ea020a6e620192589a05abf"},"headline":"Payward to acquire Bitnomial, creating a fully CFTC-licensed derivatives platform","datePublished":"2026-04-17T12:50:03+00:00","dateModified":"2026-04-17T12:52:00+00:00","mainEntityOfPage":{"@id":"https:\/\/blog.kraken.com\/news\/payward-acquires-bitnomial"},"wordCount":702,"commentCount":0,"publisher":{"@id":"https:\/\/blog.kraken.com\/#organization"},"image":{"@id":"https:\/\/blog.kraken.com\/news\/payward-acquires-bitnomial#primaryimage"},"thumbnailUrl":"https:\/\/i0.wp.com\/blog.kraken.com\/wp-content\/uploads\/2026\/04\/Kraken-Blog%402x.jpg?fit=3070%2C1400&ssl=1","articleSection":["News"],"inLanguage":"en-US","potentialAction":[{"@type":"CommentAction","name":"Comment","target":["https:\/\/blog.kraken.com\/news\/payward-acquires-bitnomial#respond"]}]},{"@type":"WebPage","@id":"https:\/\/blog.kraken.com\/news\/payward-acquires-bitnomial","url":"https:\/\/blog.kraken.com\/news\/payward-acquires-bitnomial","name":"Payward to acquire Bitnomial, creating a fully CFTC-licensed derivatives platform - Kraken Blog","isPartOf":{"@id":"https:\/\/blog.kraken.com\/#website"},"primaryImageOfPage":{"@id":"https:\/\/blog.kraken.com\/news\/payward-acquires-bitnomial#primaryimage"},"image":{"@id":"https:\/\/blog.kraken.com\/news\/payward-acquires-bitnomial#primaryimage"},"thumbnailUrl":"https:\/\/i0.wp.com\/blog.kraken.com\/wp-content\/uploads\/2026\/04\/Kraken-Blog%402x.jpg?fit=3070%2C1400&ssl=1","datePublished":"2026-04-17T12:50:03+00:00","dateModified":"2026-04-17T12:52:00+00:00","breadcrumb":{"@id":"https:\/\/blog.kraken.com\/news\/payward-acquires-bitnomial#breadcrumb"},"inLanguage":"en-US","potentialAction":[{"@type":"ReadAction","target":["https:\/\/blog.kraken.com\/news\/payward-acquires-bitnomial"]}]},{"@type":"ImageObject","inLanguage":"en-US","@id":"https:\/\/blog.kraken.com\/news\/payward-acquires-bitnomial#primaryimage","url":"https:\/\/i0.wp.com\/blog.kraken.com\/wp-content\/uploads\/2026\/04\/Kraken-Blog%402x.jpg?fit=3070%2C1400&ssl=1","contentUrl":"https:\/\/i0.wp.com\/blog.kraken.com\/wp-content\/uploads\/2026\/04\/Kraken-Blog%402x.jpg?fit=3070%2C1400&ssl=1","width":3070,"height":1400},{"@type":"BreadcrumbList","@id":"https:\/\/blog.kraken.com\/news\/payward-acquires-bitnomial#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Home","item":"https:\/\/blog.kraken.com\/"},{"@type":"ListItem","position":2,"name":"Payward to acquire Bitnomial, creating a fully CFTC-licensed derivatives platform"}]},{"@type":"WebSite","@id":"https:\/\/blog.kraken.com\/#website","url":"https:\/\/blog.kraken.com\/","name":"Kraken Blog","description":"","publisher":{"@id":"https:\/\/blog.kraken.com\/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https:\/\/blog.kraken.com\/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"},{"@type":"Organization","@id":"https:\/\/blog.kraken.com\/#organization","name":"Kraken Blog","url":"https:\/\/blog.kraken.com\/","logo":{"@type":"ImageObject","inLanguage":"en-US","@id":"https:\/\/blog.kraken.com\/#\/schema\/logo\/image\/","url":"https:\/\/i0.wp.com\/blog.kraken.com\/wp-content\/uploads\/2024\/06\/New-Lockups%402x.png?fit=214%2C64&ssl=1","contentUrl":"https:\/\/i0.wp.com\/blog.kraken.com\/wp-content\/uploads\/2024\/06\/New-Lockups%402x.png?fit=214%2C64&ssl=1","width":214,"height":64,"caption":"Kraken Blog"},"image":{"@id":"https:\/\/blog.kraken.com\/#\/schema\/logo\/image\/"}},{"@type":"Person","@id":"https:\/\/blog.kraken.com\/#\/schema\/person\/87e55a5e8ea020a6e620192589a05abf","name":"KrakenFX","image":{"@type":"ImageObject","inLanguage":"en-US","@id":"https:\/\/secure.gravatar.com\/avatar\/376cf5127aff2ae0a43942a0566f9d379956601670650244112b4fdb4b8c31e3?s=96&d=identicon&r=g","url":"https:\/\/secure.gravatar.com\/avatar\/376cf5127aff2ae0a43942a0566f9d379956601670650244112b4fdb4b8c31e3?s=96&d=identicon&r=g","contentUrl":"https:\/\/secure.gravatar.com\/avatar\/376cf5127aff2ae0a43942a0566f9d379956601670650244112b4fdb4b8c31e3?s=96&d=identicon&r=g","caption":"KrakenFX"},"url":"https:\/\/blog.kraken.com\/author\/alex-hatch"}]}
```