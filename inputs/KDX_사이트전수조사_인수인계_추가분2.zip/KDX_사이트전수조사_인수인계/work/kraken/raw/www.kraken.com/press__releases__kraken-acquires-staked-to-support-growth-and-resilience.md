---
url: https://www.kraken.com/press/releases/kraken-acquires-staked-to-support-growth-and-resilience
title: Kraken Acquires Staked to Support Growth and Resilience in One of Largest Crypto Industry Deals to Date
description: 
fetched: 2026-11-16
method: static
plan: skim
---

# 

Kraken Acquires Staked to Support Growth and Resilience in One of Largest Crypto Industry Deals to Date

[그림: Kraken Acquires Staked to Support Growth and Resilience in One of Largest Crypto Industry Deals to Date]

*Forward-thinking deal continues to solidify Kraken’s position as a world leader in staking.*

CHEYENNE, WY - December 21, 2021 - Kraken one of the world's largest digital asset platforms, today announced it has acquired Staked for an undisclosed sum in one of the largest crypto industry acquisitions to date. 

Staked is a non-custodial staking platform that enables investors in Proof-of-Stake networks to easily and securely compound their holdings. The acquisition solidifies Kraken’s position as a leading provider of staking services to consumers and institutions by expanding the number of supported networks and enabling a non-custodial alternative to Kraken’s existing custodial staking service. 

“We are excited to add Staked to our portfolio of yield products, which has seen great uptake by a growing population of crypto investors,” said Jesse Powell, CEO and co-founder of Kraken. "Staked is highly complementary to our existing staking business and will allow us to further strengthen our product offering through world-class infrastructure for clients who prefer to retain custody of their staked assets. We’re excited to welcome Staked’s clients to Kraken and believe that they will benefit from access to our wider portfolio of products as they seek to broaden their engagement with digital assets.” 

Staked's mission – to help investors earn yield from staking without relinquishing custody of their crypto assets – closely aligns with Kraken’s objective to provide seamless and secure access to staking products and services. By providing world-class infrastructure as a service, Staked removes significant barriers to entry while allowing clients to optimize rewards. 

"Kraken's acquisition of Staked represents an exciting new chapter for us,” said Tim Ogilvie, CEO of Staked. “Kraken clearly shares our commitment to supporting proof-of-stake networks, having a security-first mindset, and unwavering focus on customer experience, which makes them an ideal partner. Combining our businesses will enable us to provide a more seamless experience and expand our product offering to meet our clients’ needs in staking and beyond.” 

The acquisition of Staked – Kraken’s fifth acquisition in 2021 – is an important step in the company’s strategy to become the crypto portal of choice for both retail and professional investors. Kraken’s combined spot, margin and futures trading volume has grown by over 430% in 2021. Since the beginning of the year, the company’s staking business has grown by more than 950% to nearly $16 billion in November, resulting in token rewards valued at more than $500 million being paid out to clients. 

“The success of our staking business demonstrates that Kraken has evolved into much more than a custodian and trading venue,” said Powell. “We’ve become a holistic crypto platform with a diverse range of products that serves the needs of retail, professional, and institutional clients. Heading into the second decade in our company’s history, I’m excited about the future and Kraken’s continued support of the world’s shift to Web3 and DeFi.”

## About Kraken

Kraken is the world’s largest global digital asset platform based on euro volume and liquidity. Globally, Kraken’s client base trades more than 90 digital assets and 7 different fiat currencies, including GBP, EUR, USD, CAD, JPY, CHF and AUD. 

Kraken, now 2300+ employees, was founded in 2011 and was one of the first exchanges to offer spot trading with margin, parachain auctions, staking, regulated derivatives and index services. Kraken is trusted by over 8.5 million traders and institutions around the world and offers professional, round-the-clock online support. 

Kraken is backed by investors including Tribe Capital, SkyBridge, Hummingbird Ventures, Blockchain Capital, Digital Currency Group, among others. 

Kraken markets can be monitored and traded through the Kraken iOS and Android apps, and through the Cryptowatch iOS, Android and Desktop apps.

For more information about Kraken, please visit [www.kraken.com](https://www.kraken.com/).

## Contacts

Media inquiries: [[email protected]](https://www.kraken.com/cdn-cgi/l/email-protection)

#### Inquiries

For interview requests, logos, podcasts or conference appearances, please contact [[email protected]](https://www.kraken.com/cdn-cgi/l/email-protection)

Images available for download:

[Kraken Images](https://www.kraken.com/press/kraken-images)

### Crypto 101: A Beginner’s Guide to Crypto

[그림: Introducing Crypto 101]

Staying true to our mission to bring crypto to everyone, Kraken CEO Jesse Powell explains it all in our new video series: Crypto 101.

[See more Kraken videos](https://www.kraken.com/learn/videos)

### Kraken Facts

Recognizing the importance of Bitcoin from the onset, and understanding that the exchange is the most critical part of the cryptocurrency ecosystem, Jesse Powell co-founded Kraken to give people the means to quickly and securely invest in the space.

[그림: Kraken logo]

* Founded2011
* Total team members2,300+
* Where they livein 60+ countries
* Tokens offered90+
* Cash currencies offered7
* Supported countries190
* MascotKraken, of course
* What we call our logo“The Beast” or “Creature”

## 구조화 데이터(JSON-LD)

```json
{"@context":"https://schema.org","@graph":[{"@type":["Organization","FinancialService"],"@id":"https://www.kraken.com/#organization","name":"Kraken","legalName":"Payward, Inc.","foundingDate":"2011","url":"https://www.kraken.com/","description":"Kraken is a multi-asset financial platform founded in 2011, offering crypto, stocks, ETFs, futures and staking where available. Kraken by Payward.","parentOrganization":{"@type":"Organization","@id":"https://www.payward.com/#organization","name":"Payward","url":"https://www.payward.com/"},"subOrganization":[{"@type":"Organization","@id":"https://www.krak.app/#organization","name":"Krak","url":"https://www.krak.app/"}],"founder":[{"@type":"Person","name":"Thanh Luu"},{"@type":"Person","name":"Michael Gronager"},{"@type":"Person","name":"Jesse Powell"}],"knowsAbout":["Cryptocurrency trading","Bitcoin","Ethereum","Stock and ETF trading","Futures trading","Crypto derivatives","Tokenized equities","Digital asset custody","Staking","Payments","Institutional trading services"],"logo":{"@type":"ImageObject","@id":"https://www.kraken.com/#logo","url":"https://assets.kraken.com/marketing/static/kraken-logo.jpg","contentUrl":"https://assets.kraken.com/marketing/static/kraken-logo.jpg","width":900,"height":900,"caption":"Kraken"},"image":{"@id":"https://www.kraken.com/#logo"},"sameAs":["https://www.facebook.com/KrakenFX","https://twitter.com/krakenfx","https://www.youtube.com/@KrakenCryptoExchange","https://en.wikipedia.org/wiki/Kraken_(cryptocurrency_exchange)","https://www.linkedin.com/company/krakenfx","https://www.instagram.com/krakenfx/","https://www.reddit.com/r/Kraken","https://www.tiktok.com/@krakenfx","https://t.me/kraken_exchange_official","https://discord.com/invite/krakenexchange","https://apps.apple.com/us/app/kraken-buy-crypto-bitcoin/id1481947260","https://play.google.com/store/apps/details?id=com.kraken.invest.app&hl=en_US"],"contactPoint":{"@type":"ContactPoint","url":"https://support.kraken.com/forms","contactType":"Customer Service"},"address":{"@type":"PostalAddress","streetAddress":"1603 Capitol Ave Suite 517B","addressLocality":"Cheyenne","addressRegion":"WY","postalCode":"82001","addressCountry":"US"},"hasCertification":[{"@type":"Certification","@id":"https://www.kraken.com/#cert-iso-27001","name":"ISO/IEC 27001:2022","description":"Information Security Management System (ISMS) certification.","url":"https://www.kraken.com/features/security"},{"@type":"Certification","@id":"https://www.kraken.com/#cert-soc2-type1","name":"SOC 2 Type 1 examination (custody and funding services)","description":"SOC 2 Type 1 examination completed for custody and funding services.","url":"https://blog.kraken.com/news/kraken-completes-soc-2-type-i-for-custody-and-funding-services"}]},{"@type":"Service","@id":"https://www.kraken.com/#service-institutional-custody","name":"Institutional-grade qualified custody offering","provider":{"@id":"https://www.kraken.com/#organization"},"hasCertification":[{"@type":"Certification","@id":"https://www.kraken.com/#cert-soc2-type2","name":"SOC 2 Type 2 compliance examination (institutional-grade qualified custody offering)","description":"SOC 2 Type 2 compliance examination for the institutional-grade qualified custody offering.","url":"https://blog.kraken.com/product/security/soc-2-type-2"}]},{"@type":"WebSite","@id":"https://www.kraken.com/#website","url":"https://www.kraken.com/","name":"Kraken","alternateName":"Kraken Exchange","description":"Buy, sell, trade and learn about crypto on Kraken — the simple, powerful crypto platform that grows with you.","publisher":{"@id":"https://www.kraken.com/#organization"}},{"@type":"BreadcrumbList","@id":"https://www.kraken.com/press/releases/kraken-acquires-staked-to-support-growth-and-resilience#breadcrumb","itemListElement":[{"@type":"ListItem","position":1,"name":"Kraken.com","item":"https://www.kraken.com/"},{"@type":"ListItem","position":2,"name":"Press","item":"https://www.kraken.com/press"},{"@type":"ListItem","position":3,"name":"Releases","item":"https://www.kraken.com/press/releases"},{"@type":"ListItem","position":4,"name":"Kraken Acquires Staked To Support Growth And Resilience","item":"https://www.kraken.com/press/releases/kraken-acquires-staked-to-support-growth-and-resilience"}]},{"@type":"WebPage","@id":"https://www.kraken.com/press/releases/kraken-acquires-staked-to-support-growth-and-resilience#webpage","url":"https://www.kraken.com/press/releases/kraken-acquires-staked-to-support-growth-and-resilience","name":"Kraken Acquires Staked to Support Growth and Resilience in One of Largest Crypto Industry Deals to Date","isPartOf":{"@id":"https://www.kraken.com/#website"},"publisher":{"@id":"https://www.kraken.com/#organization"},"breadcrumb":{"@id":"https://www.kraken.com/press/releases/kraken-acquires-staked-to-support-growth-and-resilience#breadcrumb"}}]}
```