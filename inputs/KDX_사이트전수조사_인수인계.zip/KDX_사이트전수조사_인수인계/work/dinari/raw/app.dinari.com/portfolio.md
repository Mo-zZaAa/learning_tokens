---
url: https://app.dinari.com/portfolio
title: Dinari Trading App
description: Dinari trading app, leveraging Base/World frameworks + Dinari API's to provide a trading experience
fetched: 2026-11-16
method: render
plan: read
---

**Daily buy limit:** Total purchases for U.S. customers cannot exceed **$5,000** per day.

Limits may change at any time and apply per account, resetting at midnight ET. See Disclosures

[그림: Welcome to Dinari]

## Welcome to Dinari

Trade real-world stocks as blockchain tokens on Base. Own fractionalized, 1:1 asset-backed dShares, 24/7, globally.

SkipNext

# Portfolio

Connect your wallet

Connect your wallet to view your portfolio.

[Buy & Sell](https://app.dinari.com/trade)

[Market](https://app.dinari.com/)[Portfolio](https://app.dinari.com/portfolio)[Orders](https://app.dinari.com/orders)

Dinari Trading App