# 읽기 묶음: support.kraken.com / kraken (1/1)


## 목록만 둔 URL 1건 (inventory.csv에서 plan=list)
- https://support.kraken.com/kraken
- ...
